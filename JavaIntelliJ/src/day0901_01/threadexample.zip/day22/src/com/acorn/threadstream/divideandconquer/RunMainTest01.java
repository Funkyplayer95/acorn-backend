package com.acorn.threadstream.divideandconquer;

public class RunMainTest01 {

	public static void main(String[] args) {
		long lTick = 0L;
		lTick += new RunMain01().sum();
		lTick += new RunMain02().sum();
		lTick += new RunMain03().sum();
		lTick += new RunMain04().sum();
		
		System.out.println("합계: " + lTick);

	}

}
