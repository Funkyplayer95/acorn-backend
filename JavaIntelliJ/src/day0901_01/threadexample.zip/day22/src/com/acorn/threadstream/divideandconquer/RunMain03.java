package com.acorn.threadstream.divideandconquer;

public class RunMain03 {
	public long sum() {
		long lSum = 0L;
		
		long lBeforeTime = System.currentTimeMillis();
		for(int i = 500001; i < 750000; i++) {
			for(int j = 0; j < 5000; j++) {
				lSum += i * j;
			}
		}
		long lAfterTime = System.currentTimeMillis();	

		return (lAfterTime - lBeforeTime);
	}
}
