package com.acorn.threadstream.divideandconquer;

public class RunMain02 {

	public long sum() {
		long lSum = 0L;
		
		long lBeforeTime = System.currentTimeMillis();
		for(int i = 250001; i < 500000; i++) {
			for(int j = 0; j < 5000; j++) {
				lSum += i * j;
			}
		}
		long lAfterTime = System.currentTimeMillis();
		
		return (lAfterTime - lBeforeTime);
	}
}
