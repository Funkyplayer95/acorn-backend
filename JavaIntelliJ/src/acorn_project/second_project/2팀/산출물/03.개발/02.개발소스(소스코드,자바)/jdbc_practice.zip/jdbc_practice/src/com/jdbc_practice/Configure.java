package com.jdbc_practice;

public interface Configure {
	public final static String DB_URL = "jdbc:oracle:thin:@localhost:1521:xe";
	public final static String DB_USER = "project";
	public final static String DB_PASS = "ljuneh";
}
