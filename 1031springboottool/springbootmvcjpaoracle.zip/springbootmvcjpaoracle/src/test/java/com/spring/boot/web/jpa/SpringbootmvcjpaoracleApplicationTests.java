package com.spring.boot.web.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootmvcjpaoracleApplicationTests {

	@Test
	void contextLoads() {
	}

}
