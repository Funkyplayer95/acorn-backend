package com.spring.boot.web.jpa.join.dto;

public interface ReturnDataList {
	
}
