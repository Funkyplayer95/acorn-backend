package com.spring.boot.web.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootmvcjpaoracleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootmvcjpaoracleApplication.class, args);
	}

}
