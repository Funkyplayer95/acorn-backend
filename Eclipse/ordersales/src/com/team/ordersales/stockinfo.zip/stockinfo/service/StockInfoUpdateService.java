package com.team.ordersales.stockinfo.service;

import javax.servlet.http.HttpServletRequest;

import com.team.ordersales.stockinfo.entity.StockInfoEntity;


public class StockInfoUpdateService {
	
	public void stockInfoReset(StockInfoEntity stockInfoEntity, HttpServletRequest req) {
		
	}

}
