package com.springaop;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class RunMain {

	private static ClassPathXmlApplicationContext ctx = null;
	
	public static void main(String[] args) {
		ctx = new ClassPathXmlApplicationContext("classpath:/com/springaop/config.xml");
		
		ProductService productService = 
				(ProductService)ctx.getBean("productService");
		
		productService.multiply(102, 302);
		
		ctx.close();

	}

}
