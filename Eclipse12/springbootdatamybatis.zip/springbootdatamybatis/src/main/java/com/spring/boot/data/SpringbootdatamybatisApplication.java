package com.spring.boot.data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// @Configuration + @EnableAutoConfiguration + @MapperScan
@SpringBootApplication
public class SpringbootdatamybatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootdatamybatisApplication.class, args);
	}

}
