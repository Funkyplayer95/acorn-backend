package com.springmybatis.dao.impl;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springmybatis.dao.IMemberDao;
import com.springmybatis.dto.Member;
import com.springmybatis.dto.UpdateConditions;

@Repository
public class MemberDaoImpl implements IMemberDao{

	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;

	@Override
	public Member findMemberById(int id) {		
		return sqlSessionTemplate.selectOne(
				"member.findMemberId", id);
	}

	@Override
	public int insertMember(Member member) {
		return sqlSessionTemplate.insert("member.insertMember", member);
	}

	@Override
	public int updateMemberById(int id, String address) {
		UpdateConditions uc = new UpdateConditions(id, address);
		return sqlSessionTemplate.update("member.updateMemberById", uc);
	}

	@Override
	public List<Member> findMember() {
		return sqlSessionTemplate.selectList("member.findmMember");
	}
}
