package com.springmybatis.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springmybatis.dao.IMemberDao;
import com.springmybatis.dto.Member;
import com.springmybatis.service.IMemberService;

@Service
public class MemberServiceImpl implements IMemberService {
	
	@Autowired
	private IMemberDao memberDao;

	@Override
	public List<Member> findMember() {
		return memberDao.findMember();
	}
	
	@Override
	public Member findMemberById(int id) {	
		return memberDao.findMemberById(id);
	}

	@Override
	public int insertMember(Member member) {
		return memberDao.insertMember(member);
	}

	@Override
	public int updateMemberById(int id, String address) {
		return memberDao.updateMemberById(id, address);
	}
}
