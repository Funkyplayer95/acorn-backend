package com.springmybatis.service;

import java.util.List;

import com.springmybatis.dto.Member;

public interface IMemberService {
	
	public Member findMemberById(int id);
	public int insertMember(Member member);
	public int updateMemberById(int id, String address);
	public List<Member> findMember();
}
