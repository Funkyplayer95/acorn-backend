package com.springmybatis.dao;

import java.util.List;

import com.springmybatis.dto.Member;


public interface IMemberDao {
	
	Member findMemberById(int id);
	
	List<Member> findMember();
	
	int insertMember(Member member);
	
	int updateMemberById(int id, String address);
	
}
