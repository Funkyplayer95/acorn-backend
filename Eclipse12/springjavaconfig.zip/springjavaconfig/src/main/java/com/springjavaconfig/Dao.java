package com.springjavaconfig;

public class Dao {
	
	public void create() {
		System.out.println("Created");
	}
}
