package FinalProject.TagMatch.Service;

import FinalProject.TagMatch.DTO.UserDTO;
import FinalProject.TagMatch.Entity.User;
import FinalProject.TagMatch.Repository.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class SideService {

    private final UserRepository userRepository;

    public List<UserDTO> userinfo(){
        List<User> uu  = userRepository.findAll();
        List<UserDTO> dt = new ArrayList<UserDTO>();

        for ( User en : uu) {
            UserDTO DTList = new UserDTO(
                    en.getUsernumber(),
                    en.getEmail(),
                    en.getName(),
                    en.getAge(),
                    en.getGender()
            );
            dt.add(DTList);
        }
        return dt;
    }

    public UserDTO showName(String email){

        User uu = userRepository.findByEmail(email);
        UserDTO dt = new UserDTO();
        if( uu != null)
            dt.setName(uu.getName());

        return dt;
    }

}
