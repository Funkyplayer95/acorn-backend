package FinalProject.TagMatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TagMatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(TagMatchApplication.class, args);
	}

}
