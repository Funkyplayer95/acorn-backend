package FinalProject.TagMatch.Entity;


import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Table(name = "user")
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class User {

 @Id
 private int usernumber;

 private String email;
 private String name;
 private int age;
 private String gender;


}
