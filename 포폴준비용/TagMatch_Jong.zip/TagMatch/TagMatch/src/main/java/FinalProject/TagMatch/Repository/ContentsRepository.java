package FinalProject.TagMatch.Repository;

import FinalProject.TagMatch.Entity.Contents;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContentsRepository extends JpaRepository<Contents, String> {


}
