package FinalProject.TagMatch.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Contents {

    @Id
    String contentsnumber;

    int platformid;
    String writer;
    String content;
    String date;
    String gtags;
    String comments;
    String url;

}
