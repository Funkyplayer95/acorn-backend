package FinalProject.TagMatch.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MypageController {
//    @GetMapping("/mypage") //url
//    public static String myPage(Model model){
//        return "mypage"; //html이름

//    }
}

