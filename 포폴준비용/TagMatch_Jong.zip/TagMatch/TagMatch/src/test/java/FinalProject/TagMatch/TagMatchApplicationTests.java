package FinalProject.TagMatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TagMatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
